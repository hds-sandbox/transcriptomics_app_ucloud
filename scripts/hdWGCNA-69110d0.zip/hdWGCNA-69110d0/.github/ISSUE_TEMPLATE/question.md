---
name: Question
about: Ask a specific question about using the hdWGCNA package.
title: Question about [my question]
labels: question
assignees: ''

---

**Describe your question** 
Provide a clear and concise question regarding the hdWGCNA package, and ensure to include all of the relevant details to understand your question. If you have more than one question, please open separate GitHub issues.
