# v0.2.0

- Added host to data retrieval function
- Updated all recipes to use https
