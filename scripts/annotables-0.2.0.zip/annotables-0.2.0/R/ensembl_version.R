#' Ensembl version used for build
#'
#' @examples
#' ensembl_version
#'
#' @source \url{http://www.ensembl.org/}
#' @docType data
"ensembl_version"
