library(testthat)
library(ggforestplot)

test_check("ggforestplot")
