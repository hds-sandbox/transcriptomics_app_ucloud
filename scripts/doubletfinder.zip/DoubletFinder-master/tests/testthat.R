library(testthat)
library(DoubletFinder)

test_check("DoubletFinder")
